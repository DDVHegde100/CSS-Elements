// GSAP method (must remove animation from CSS):

// gsap.to(".ring", {
//   scale: 1.75,
//   opacity: 0,
//   duration: 2,
//   stagger: {
//     each: 0.5,
//     repeat: -1
//   }
// });